<?php

echo $_POST["query"];

?>
