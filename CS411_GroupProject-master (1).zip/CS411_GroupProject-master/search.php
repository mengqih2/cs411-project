<?php

$dataset = $_POST["dataset"];

switch ($dataset) {
  case "professor":
    $id = $_POST["id"];
    $name = $_POST["name"];
    $rating = $_POST["rating"];
    $department = $_POST["department"];

    echo "SELECT * FROM ".$dataset;
    echo "<br>";
    echo "WHERE ";
    if ($id != NULL) {
      echo "id='".$id."'";
      if ($name != NULL or $rating != NULL or $department != NULL) {
        echo " AND ";
      }
    }
    if ($name != NULL) {
      echo "name='".$name."'";
      if ($rating != NULL or $department != NULL) {
        echo " AND ";
      }
    }
    if ($rating != NULL) {
      echo "rating='".$rating."'";
      if ($department != NULL) {
        echo " AND ";
      }
    }
    if ($department != NULL) {
      echo "department='".$department."'";
    }
    echo "<br>";


    break;

  case "major":
    $id = $_POST["id"];
    $name = $_POST["name"];
    $college = $_POST["college"];
    $department = $_POST["department"];

    echo "SELECT * FROM ".$dataset;
    echo "<br>";
    echo "WHERE ";
    if ($id != NULL) {
      echo "id='".$id."'";
      if ($name != NULL or $college != NULL or $department != NULL) {
        echo " AND ";
      }
    }
    if ($name != NULL) {
      echo "name='".$name."'";
      if ($college != NULL or $department != NULL) {
        echo " AND ";
      }
    }
    if ($college != NULL) {
      echo "college='".$college."'";
      if ($department != NULL) {
        echo " AND ";
      }
    }
    if ($department != NULL) {
      echo "department='".$department."'";
    }
    echo "<br>";


    break;
EOF;

    break;

  case "course":
    $crn = $_POST["crn"];
    $name = $_POST["name"];
    $number = $_POST["number"];
    $major = $_POST["major"];

    echo "SELECT * FROM ".$dataset;
    echo "<br>";
    echo "WHERE ";
    if ($crn != NULL) {
      echo "crn='".$crn."'";
      if ($name != NULL or $number != NULL or $major != NULL) {
        echo " AND ";
      }
    }
    if ($name != NULL) {
      echo "name='".$name."'";
      if ($number != NULL or $major != NULL) {
        echo " AND ";
      }
    }
    if ($number != NULL) {
      echo "number='".$number."'";
      if ($major != NULL) {
        echo " AND ";
      }
    }
    if ($major != NULL) {
      echo "major='".$major."'";
    }
    echo "<br>";

    break;

  case "gened":
    $crn = $_POST["crn"];
    $name = $_POST["name"];
    $number = $_POST["number"];
    $major = $_POST["major"];
    $type = $_POST["type"];

    echo "SELECT * FROM ".$dataset;
    echo "<br>";
    echo "WHERE ";
    if ($crn != NULL) {
      echo "crn='".$crn."'";
      if ($name != NULL or $number != NULL or $major != NULL or $type != NULL) {
        echo " AND ";
      }
    }
    if ($name != NULL) {
      echo "name='".$name."'";
      if ($number != NULL or $major != NULL or $type != NULL) {
        echo " AND ";
      }
    }
    if ($number != NULL) {
      echo "number='".$number."'";
      if ($major != NULL or $type != NULL) {
        echo " AND ";
      }
    }
    if ($major != NULL) {
      echo "major='".$major."'";
      if ($type != NULL) {
        echo " AND ";
      }
    }
    if ($type != NULL) {
      echo "type='".$type."'";
    }
    echo "<br>";

    break;

  case "teaches":
    $crn = $_POST["crn"];
    $professor = $_POST["professor"];
    $gpa = $_POST["gpa"];

    echo "SELECT * FROM ".$dataset;
    echo "<br>";
    echo "WHERE ";
    if ($crn != NULL) {
      echo "crn='".$crn."'";
      if ($professor != NULL or $gpa != NULL) {
        echo " AND ";
      }
    }
    if ($professor != NULL) {
      echo "professor='".$professor."'";
      if ($gpa != NULL) {
        echo " AND ";
      }
    }
    if ($gpa != NULL) {
      echo "gpa='".$gpa."'";
    }
    echo "<br>";

    break;

  default:
    break;
}

?>
