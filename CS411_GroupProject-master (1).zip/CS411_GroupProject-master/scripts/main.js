function cll(id){
    if (id==0) {
         eval("div0.style.display=\"\";");
         eval("div1.style.display=\"none\";");
         eval("div2.style.display=\"none\";");
         eval("div3.style.display=\"none\";");
         eval("div4.style.display=\"none\";");}
   else if (id==1){
         eval("div0.style.display=\"none\";");
         eval("div1.style.display=\"\";");
         eval("div2.style.display=\"none\";");
         eval("div3.style.display=\"none\";");
         eval("div4.style.display=\"none\";");}
   else if (id==2){
         eval("div0.style.display=\"none\";");
         eval("div1.style.display=\"none\";");
         eval("div2.style.display=\"\";");
         eval("div3.style.display=\"none\";");
         eval("div4.style.display=\"none\";");}
   else if (id==3){
         eval("div0.style.display=\"none\";");
         eval("div1.style.display=\"none\";");
         eval("div2.style.display=\"none\";");
         eval("div3.style.display=\"\";");
         eval("div4.style.display=\"none\";");}
   else if (id==4){
         eval("div0.style.display=\"none\";");
         eval("div1.style.display=\"none\";");
         eval("div2.style.display=\"none\";");
         eval("div3.style.display=\"none\";");
         eval("div4.style.display=\"\";");}
   else {
      eval("div0.style.display=\"none\";");
      eval("div1.style.display=\"none\";");
      eval("div2.style.display=\"none\";");
      eval("div3.style.display=\"none\";");
      eval("div4.style.display=\"none\";");}
}

function submitSuccess() {
   eval("submit-success.style.display=\"\";");
}

table.render({
  elem: '#output'
  ,height: 420
  ,url: '/demo/table/user'
  ,title: 'user_table'
  ,page: true
  ,toolbar: 'default'
  ,totalRow: true
  ,cols: [[
    {type: 'checkbox', fixed: 'left'}
    ,{field: 'id', title: 'ID', width:80, sort: true, fixed: 'left', totalRowText: 'total:'}
    ,{field: 'name', title: 'name', width:80}
    ,{field: 'price', title: 'price', width: 90, sort: true, totalRow: true}
    ,{fixed: 'right', width: 165, align:'center', toolbar: '#barDemo'}
  ]]
});

  //监听头工具栏事件
table.on('toolbar(test)', function(obj){
  var checkStatus = table.checkStatus(obj.config.id)
  ,data = checkStatus.data; //获取选中的数据
  switch(obj.event){
    case 'add':
      layer.msg('add');
    break;
    case 'update':
      if(data.length === 0){
        layer.msg('please select only one row');
      } else if(data.length > 1){
        layer.msg('one row to edit at one time');
      } else {
        layer.alert('edit [id]：'+ checkStatus.data[0].id);
      }
    break;
    case 'delete':
      if(data.length === 0){
        layer.msg('please select one row');
      } else {
        layer.msg('delect');
      }
    break;
  };
});

 //监听行工具事件
table.on('tool(test)', function(obj){ //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
  var data = obj.data //获得当前行数据
  ,layEvent = obj.event; //获得 lay-event 对应的值
  if(layEvent === 'detail'){
    layer.msg('detail');
  } else if(layEvent === 'del'){
    layer.confirm('confirm to  select', function(index){
      obj.del(); //删除对应行（tr）的DOM结构
      layer.close(index);
      //向服务端发送删除指令
    });
  } else if(layEvent === 'edit'){
    layer.msg('edit');
  }
});

//分页
laypage.render({
  elem: 'pageDemo' //分页容器的id
  ,count: 100 //总页数
  ,skin: '#1E9FFF' //自定义选中色值
  //,skip: true //开启跳页
  ,jump: function(obj, first){
    if(!first){
      layer.msg('page ' + obj.curr, {offset: 'b'});
    }
  }
});
//
// $(document).ready(function() {
//     $.ajax({
//         type: "GET",
//         url: "1.csv",
//         dataType: "text",
//         success: function(data) {processData(data);}
//      });
// });
//
// function csvJSON(csv){
//   var lines=csv.split("\n");
//   var result = [];
//   var headers=lines[0].split(",");
//   for(var i=1;i<lines.length;i++){
// 	  var obj = {};
// 	  var currentline=lines[i].split(",");
// 	  for(var j=0;j<headers.length;j++){
// 		  obj[headers[j]] = currentline[j];
// 	  }
// 	  result.push(obj);
//   }
//   //return result; //JavaScript object
//   return JSON.stringify(result); //JSON
}
