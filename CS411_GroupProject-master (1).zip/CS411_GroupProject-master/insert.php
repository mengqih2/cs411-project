<?php

$dataset = $_POST["dataset"];

switch ($dataset) {
  case "professor":
    $id = $_POST["id"];
    $name = $_POST["name"];
    $rating = $_POST["rating"];
    $department = $_POST["department"];

    echo <<<EOF
    INSERT INTO $dataset (id, name, rating, department)<br>
    VALUE ($id, $name, $rating, $department)
EOF;

    break;

  case "major":
    $id = $_POST["id"];
    $name = $_POST["name"];
    $college = $_POST["college"];
    $department = $_POST["department"];

    echo <<<EOF
    INSERT INTO $dataset (id, name, college, department)<br>
    VALUE ($id, $name, $college, $department)
EOF;

    break;

  case "course":
    $crn = $_POST["crn"];
    $name = $_POST["name"];
    $number = $_POST["number"];
    $major = $_POST["major"];

    echo <<<EOF
    INSERT INTO $dataset (crn, name, major, number)<br>
    VALUE ($crn, $name, $major, $number)
EOF;

    break;

  case "gened":
    $crn = $_POST["crn"];
    $name = $_POST["name"];
    $number = $_POST["number"];
    $major = $_POST["major"];
    $type = $_POST["type"];

    echo <<<EOF
    INSERT INTO $dataset (crn, name, major, number, type)<br>
    VALUE ($crn, $name, $major, $number, $type)
EOF;

    break;

  case "teaches":
    $crn = $_POST["crn"];
    $professor = $_POST["professor"];
    $gpa = $_POST["gpa"];

    echo <<<EOF
    INSERT INTO $dataset (crn, professor, gpa)<br>
    VALUE ($crn, $professor, $gpa)
EOF;

    break;

  default:
    break;
}

?>
