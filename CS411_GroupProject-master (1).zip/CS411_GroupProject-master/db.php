<?php
/* Database connection settings */
$host = 'localhost';
$user = 'user';
$pass = 'password';
$db = 'veggiebirds_users';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);

?>
